﻿//Michael Brannon

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    class Graph
    {
        private object[] vertices;
        private bool[,] edges;

        public Graph(int numVertices)
        {
            if (numVertices < 0)
            {
                throw new Exception("A graph can't have a negative number of vertices");
            }
            vertices = new object[numVertices];
            edges = new bool[numVertices, numVertices];
        }
        public void addVertexData(int vertexNumber, object vertexData)
        {
            if (vertexNumber < 0 && vertexNumber >= vertices.Length)
            {
                throw new Exception("Vertex number is out of bounds");
            }
            vertices[vertexNumber] = vertexData;
        }
        public void addEdge(int vertex1, int vertex2)
        {
            if (vertex1 >= 0 && vertex1 < vertices.Length && vertex2 >= 0 && vertex2 < vertices.Length && vertex1 != vertex2)
            {
                edges[vertex1, vertex2] = true;
                edges[vertex2, vertex1] = true;
            }
            else
            {
                throw new Exception("Vertex number is out of bounds");
            }
        }
        public void removeEdge(int vertex1, int vertex2)
        {
            if (vertex1 >= 0 && vertex1 < vertices.Length && vertex2 >= 0 && vertex2 < vertices.Length)
            {
                edges[vertex1, vertex2] = false;
                edges[vertex2, vertex1] = false;
            }
            else
            {
                throw new Exception("Vertex number is out of bounds");
            }
        }
        public bool hasEdge(int vertex1, int vertex2)
        {
            if (vertex1 >= 0 && vertex1 < vertices.Length && vertex2 >= 0 && vertex2 < vertices.Length)
            {
                return edges[vertex1, vertex2];
            }
            else
            {
                throw new Exception("Vertex number is out of bounds");
            }
        }
        public object getVertexData(int vertexNumber)
        {
            if (vertexNumber >= 0 && vertexNumber < vertices.Length)
            {
                return vertices[vertexNumber];
            }
            else
            {
                throw new Exception("Vertex number is out of bounds");
            }
        }
        public int getNumVertices()
        {
            return vertices.Length;
        }

        private void DFS(int vertex, bool[] visited)
        {
            visited[vertex] = true;

            for (int i = 0; i < vertices.Length; i++)
            {
                if (edges[vertex, i] && !visited[i])
                {
                    DFS(i, visited);
                }
            }
        }

        public bool isConnected()
        {
            bool[] visited = new bool[vertices.Length];
            DFS(0, visited);

            for (int i = 0; i < vertices.Length; i++)
            {
                if (!visited[i]) return false;
            }
            return true;
        }

        

        private bool DFSValue(int vertex, bool[] visited, int parent)
        {
            visited[vertex] = true;

            for (int i = 0; i < vertices.Length; i++)
            {
                if (edges[vertex, i])
                {
                    if (!visited[i])
                    {
                        if (DFSValue(i, visited, vertex)) return true;
                    }
                    else if (i != parent) return true;
                }
            }
            return false;
        }

        public bool hasCycle()
        {
            bool[] visited = new bool[vertices.Length];
            return DFSValue(0, visited, -1);

        }
        public bool isTree()
        {
            return isConnected() && !hasCycle();
        }
        public override string ToString()
        {
            return "Graph Representation";
        }
        
    }
}
