﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2
{
    internal class TestGraph
    {
        public static void Main()
        {
            // (a) Create a Graph g with 32 vertices;
            Graph g = new Graph(32);

            // (b) Store the numbers 0 through 31 in the vertices, in that order;
            for (int i = 0; i < 32; i++)
            {
                g.addVertexData(i, i);
            }

            // (c) Join all pairs of vertices of the form {j, j/2} where j is between 1 and
            // 31, and where j/2 is computed as usual with integer division;
            for (int j = 1; j <= 31; j++)
            {
                int vertex1 = j;
                int vertex2 = j / 2;
                g.addEdge(j, j/2);
            }
            
            

            // (d) Test g for connectedness;
            bool isConnected = g.isConnected();
            Console.WriteLine("Is Graph Connected: " + isConnected);

            // (e) Test g for cycles;
            bool hasCycle = g.hasCycle();
            Console.WriteLine("Graph has Cycle: " + hasCycle);

            // (f) Test whether g is a tree.
            bool isTree = g.isTree();
            Console.WriteLine("Is Graph a Tree: " + isTree);

            //Q2
            g.removeEdge(1, 3);

            isConnected = g.isConnected();
            Console.WriteLine("Is Graph Connected after removing edge (1,3): " + isConnected);

            hasCycle = g.hasCycle();
            Console.WriteLine("Graph has Cycle after removing edge (1,3): " + hasCycle);

            isTree = g.isTree();
            Console.WriteLine("Is Graph a Tree after removing edge (1,3): " + isTree);

            //Q3

            g.addEdge(21, 22);

            isConnected = g.isConnected();
            Console.WriteLine("Is Graph Connected after adding edge (21,22): " + isConnected);

            hasCycle = g.hasCycle();
            Console.WriteLine("Graph has Cycle after adding edge (21,22): " + hasCycle);

            isTree = g.isTree();
            Console.WriteLine("Is Graph a Tree after adding edge (21,22): " + isTree);

            //Q4
            g.addEdge(1, 3);

            isConnected = g.isConnected();
            Console.WriteLine("Is Graph Connected after adding back edge (1,3): " + isConnected);

            hasCycle = g.hasCycle();
            Console.WriteLine("Graph has Cycle after adding back edge (1,3): " + hasCycle);

            isTree = g.isTree();
            Console.WriteLine("Is Graph a Tree after adding back edge (1,3): " + isTree);


            //Q5
            try
            {
                g.addEdge(1, 1);
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception: " + e.Message);

            }
        }
    }
}
