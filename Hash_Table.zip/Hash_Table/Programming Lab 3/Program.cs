﻿//Michael Brannon

using Programming_Lab_3;
using System;
using System.Drawing;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Intrinsics.X86;
using System.Xml.Linq;

namespace Programming_Lab_3
{

    class HashTable<T>
    where T : IKeyed
    {
        private T[] items;
        private bool linearProbing;
        private bool[] occupied;

        public HashTable(int theSize, bool useLinearProbing = false) //optional parameter useLinearProbing defaults to false
        {
            if (theSize <= 0)
                throw new ArgumentException("Size must be positive.");
            if (!useLinearProbing)
            {
                theSize = getNextValidSize(theSize); 
            }
            items = new T[theSize];
            occupied = new bool[theSize];
            linearProbing = useLinearProbing;

        }

        public void addItem(T theItem)
        {
            int key = theItem.getKey();
            int e = hashFunction(key);
            for (int i = 0; i < items.Length; i++)
            {
                int Index = probe(e, i); 

                if (!occupied[Index]) 
                {
                    items[Index] = theItem; 
                    occupied[Index] = true; 
                    return;
                }
            }

            throw new Exception("HashTable is full: unable to add item!");
        }

        public bool retrieveItem(ref T theItem)
        {
            int key = theItem.getKey();
            int e = hashFunction(key);
            for (int i = 0; i < items.Length; i++)
            {
                int Index = probe(e, i); 
                if (occupied[Index]) 
                {
                    if (items[Index] != null && items[Index].getKey() == key) 
                    {
                        theItem = items[Index]; 
                        return true;
                    }
                }
                else
                {
                    break; 
                }
            }

            return false; 
        }

        private int LinearProbe(int e, int i)
        {
            return (e + i) % items.Length; 
        }

        private int quadraticProbe(int e, int i)
        {
            int toSquare;
            if (i % 2 != 0)
            {
                toSquare = (i + 1) / 2;
            }
            else
            {
                toSquare = i / 2;
            }
            
            int mulitplyByOneOrNegativeOne;
            if (i % 2 == 0)
            {
                mulitplyByOneOrNegativeOne = -1;
            }
            else
            {
                mulitplyByOneOrNegativeOne = 1;
            }
            
            int theSquare = toSquare * toSquare;
            int returnValue = (e + theSquare * mulitplyByOneOrNegativeOne) % items.Length;
            if (returnValue < 0)
            {
                returnValue += items.Length;
            }

            return returnValue;
        }
    
        private int probe(int e, int i)
        {
            int returnValue;
            if (linearProbing)
            {
                returnValue = LinearProbe(e, i);
            }
            else
            {
                returnValue = quadraticProbe(e, i);
            }
            return returnValue;
        }

        private int getNextValidSize(int size)
        {
            while (!TheoremQ(size))
            {
                size++;
            }
            return size; 
        }

        
        private bool TheoremQ(int size)
        {
            if (size == 1 || size == 2)
                return true; 

            if (isPrime(size) && size % 4 == 3)
                return true; 

            if (size % 2 == 0 && isPrime(size / 2) && (size / 2) % 4 == 3)
                return true; 

            return false; 
        }

        
        private bool isPrime(int size)
        {
            if (size <= 1)
                return false;

            for (int i = 2; i <= Math.Sqrt(size); i++)
            {
                if (size % i == 0)
                    return false;
            }

            return true;
        }

        public int hashFunction(int keyValue)
        {
            return keyValue % items.Length;
        }
        
    
    }



    public class Person : IKeyed
    {
        private string name ;
        private string SSN;
        private int age;

        public Person(string theSSN, string theName, int theAge)
        {
            name = theName;
            SSN = theSSN;
            age = theAge;
        }
        public int getKey()
        {
            return int.Parse(SSN);
        }
    }
    public interface IKeyed
    {
        int getKey();
    }
}