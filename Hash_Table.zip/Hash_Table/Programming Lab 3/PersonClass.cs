﻿//Michael Brannon

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programming_Lab_3
{
    internal class PersonClass
        {
            public static void Main()
            {
                int capacity = 10;
                HashTable<Person> t = new HashTable<Person>(capacity, false);
                Person x = new Person("000000001", "John Doe", 20);
                for (int i = 0; i < capacity; i++)
                {
                    t.addItem(x);
                }
                t.addItem(x);
                Person y = new Person("000000001", "", 0);
                bool found = t.retrieveItem(ref y);
                Console.WriteLine(found);
            }
    }
}

