﻿namespace GraphicChess
{
    partial class ChessGameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Game = new System.Windows.Forms.ToolStripMenuItem();
            this.undoMoveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoMoveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startNewGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.radioButtonResign = new System.Windows.Forms.RadioButton();
            this.radioButtonComputerDecides = new System.Windows.Forms.RadioButton();
            this.radioButtonUserDecides = new System.Windows.Forms.RadioButton();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.autoMatchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Game});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1045, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Game
            // 
            this.Game.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoMoveToolStripMenuItem,
            this.redoMoveToolStripMenuItem,
            this.startNewGameToolStripMenuItem,
            this.autoMatchToolStripMenuItem});
            this.Game.Name = "Game";
            this.Game.Size = new System.Drawing.Size(62, 24);
            this.Game.Text = "Game";
            // 
            // undoMoveToolStripMenuItem
            // 
            this.undoMoveToolStripMenuItem.Name = "undoMoveToolStripMenuItem";
            this.undoMoveToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.undoMoveToolStripMenuItem.Text = "Undo Last Move";
            this.undoMoveToolStripMenuItem.Click += new System.EventHandler(this.undoMoveToolStripMenuItem_Click);
            // 
            // redoMoveToolStripMenuItem
            // 
            this.redoMoveToolStripMenuItem.Name = "redoMoveToolStripMenuItem";
            this.redoMoveToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.redoMoveToolStripMenuItem.Text = "Redo Move";
            this.redoMoveToolStripMenuItem.Click += new System.EventHandler(this.redoMoveToolStripMenuItem_Click);
            // 
            // startNewGameToolStripMenuItem
            // 
            this.startNewGameToolStripMenuItem.Name = "startNewGameToolStripMenuItem";
            this.startNewGameToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.startNewGameToolStripMenuItem.Text = "Start New Game";
            this.startNewGameToolStripMenuItem.Click += new System.EventHandler(this.startNewGameToolStripMenuItem_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(936, 417);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(100, 28);
            this.btnSubmit.TabIndex = 16;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // radioButtonResign
            // 
            this.radioButtonResign.AutoSize = true;
            this.radioButtonResign.Location = new System.Drawing.Point(741, 346);
            this.radioButtonResign.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonResign.Name = "radioButtonResign";
            this.radioButtonResign.Size = new System.Drawing.Size(73, 21);
            this.radioButtonResign.TabIndex = 15;
            this.radioButtonResign.TabStop = true;
            this.radioButtonResign.Text = "Resign";
            this.radioButtonResign.UseVisualStyleBackColor = true;
            // 
            // radioButtonComputerDecides
            // 
            this.radioButtonComputerDecides.AutoSize = true;
            this.radioButtonComputerDecides.Location = new System.Drawing.Point(741, 318);
            this.radioButtonComputerDecides.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonComputerDecides.Name = "radioButtonComputerDecides";
            this.radioButtonComputerDecides.Size = new System.Drawing.Size(226, 21);
            this.radioButtonComputerDecides.TabIndex = 14;
            this.radioButtonComputerDecides.TabStop = true;
            this.radioButtonComputerDecides.Text = "Let computer decide next move";
            this.radioButtonComputerDecides.UseVisualStyleBackColor = true;
            // 
            // radioButtonUserDecides
            // 
            this.radioButtonUserDecides.AutoSize = true;
            this.radioButtonUserDecides.Location = new System.Drawing.Point(741, 289);
            this.radioButtonUserDecides.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radioButtonUserDecides.Name = "radioButtonUserDecides";
            this.radioButtonUserDecides.Size = new System.Drawing.Size(130, 21);
            this.radioButtonUserDecides.TabIndex = 13;
            this.radioButtonUserDecides.TabStop = true;
            this.radioButtonUserDecides.Text = "This is my move";
            this.radioButtonUserDecides.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(741, 202);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(132, 22);
            this.textBox2.TabIndex = 11;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(741, 234);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(132, 22);
            this.textBox1.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(703, 238);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "To:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(689, 206);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "From:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(663, 53);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 17);
            this.label3.TabIndex = 17;
            this.label3.Text = "Message:";
            // 
            // txtMessage
            // 
            this.txtMessage.CausesValidation = false;
            this.txtMessage.Enabled = false;
            this.txtMessage.Location = new System.Drawing.Point(741, 53);
            this.txtMessage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMessage.MaximumSize = new System.Drawing.Size(293, 122);
            this.txtMessage.MinimumSize = new System.Drawing.Size(293, 122);
            this.txtMessage.Multiline = true;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMessage.Size = new System.Drawing.Size(293, 122);
            this.txtMessage.TabIndex = 18;
            this.txtMessage.TabStop = false;
            // 
            // autoMatchToolStripMenuItem
            // 
            this.autoMatchToolStripMenuItem.Name = "autoMatchToolStripMenuItem";
            this.autoMatchToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.autoMatchToolStripMenuItem.Text = "Auto Match";
            this.autoMatchToolStripMenuItem.Click += new System.EventHandler(this.autoMatchToolStripMenuItem_Click);
            // 
            // ChessGameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1045, 455);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.radioButtonResign);
            this.Controls.Add(this.radioButtonComputerDecides);
            this.Controls.Add(this.radioButtonUserDecides);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "ChessGameForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ChessGame_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Game;
        private System.Windows.Forms.ToolStripMenuItem undoMoveToolStripMenuItem;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.RadioButton radioButtonResign;
        private System.Windows.Forms.RadioButton radioButtonComputerDecides;
        private System.Windows.Forms.RadioButton radioButtonUserDecides;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.ToolStripMenuItem redoMoveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startNewGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem autoMatchToolStripMenuItem;
    }
}

