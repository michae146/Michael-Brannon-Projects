﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Threading;

namespace GraphicChess
{
    public partial class ChessGameForm : Form
    {
        private const int boardSize = ChessGame.boardSize;
        private int boardSquareWidth = 40, boardSquareHeight = 40, boardHOffset = 30, boardVOffset = 30;//in pixels
        private ChessGame theChessGame;
        private List<ChessGame.ChessMove> moveHistory;
        private int moveIndex;
        public ChessGameForm()
        {
            InitializeComponent();
            undoMoveToolStripMenuItem.Enabled = redoMoveToolStripMenuItem.Enabled = false;
            btnSubmit.Enabled = false;
        }

        private void form_Click(object sender, EventArgs e)
        {
            MouseEventArgs me = (MouseEventArgs)e;
            int x = (me.X - boardHOffset) / boardSquareWidth;
            int y = boardSize - 1 - (me.Y - boardVOffset) / boardSquareHeight;
            if (!ChessGame.isOnBoard(new ChessGame.Point(x, y))) return;
            if (me.Button == System.Windows.Forms.MouseButtons.Left)
            {
                textBox2.Text = x + "," + y;
            }
            else
            {
                textBox1.Text = x + "," + y;
            }
            drawBoard();
        }

        private void playChess()
        {
            drawBoard();
        }

        private void drawBoard()
        {
            System.Drawing.Graphics graphics = CreateGraphics();

	        int i,j;
	        ChessGame.Piece piece;
            Rectangle boardRect = new Rectangle(boardHOffset, boardVOffset, boardSize * boardSquareWidth, boardSize * boardSquareHeight);
            Rectangle squareRect, innerRect;
            graphics.Clip = new Region(boardRect);
            Pen greenPen = new Pen(new SolidBrush(Color.Green), 5), redPen = new Pen(new SolidBrush(Color.Red), 5);
            SolidBrush whiteBrush = new SolidBrush(Color.White), blackBrush = new SolidBrush(Color.Black);
            graphics.FillRectangle(whiteBrush, boardRect);

	        for(i = 0; i <= boardSize; i++)
	        {
                graphics.DrawLine(System.Drawing.Pens.Black, i * boardSquareWidth + boardHOffset, boardVOffset, i * boardSquareWidth + boardHOffset, boardVOffset + boardSquareHeight * boardSize);
                graphics.DrawLine(System.Drawing.Pens.Black, boardHOffset, i * boardSquareHeight + boardVOffset, boardHOffset + boardSquareWidth * boardSize, i * boardSquareHeight + boardVOffset);
	        }

	        Rectangle Rect;

	        for(j = 0; j < boardSize; j++)
	        {
		        for(i = 0; i < boardSize; i++)
		        {
                    Rect = new Rectangle(i * boardSquareWidth + boardHOffset, (boardSize - 1 - j) * boardSquareHeight + boardVOffset, boardSquareWidth, boardSquareHeight);
			        squareRect = Rect;
                    squareRect.Y = squareRect.Bottom - boardSquareHeight;
			        innerRect = squareRect;
                    innerRect.Y += boardSquareHeight / 5;
                    innerRect.Height -= boardSquareHeight / 5;
                    innerRect.X += boardSquareWidth / 5;
                    innerRect.Width -= boardSquareWidth / 5;

			        if((i + j) % 2 == 0)
			        {
                        graphics.FillRectangle(blackBrush, squareRect);
			        }

			        piece = theChessGame.getPiece(new ChessGame.Point(i, j));
			        if(piece != null)
			        {
                        graphics.DrawImage(piece.imageFile, innerRect);
			        }
		        }
	        }

            ChessGame.Point from, to;
            getFromTo(out from, out to);
            if (ChessGame.isOnBoard(from)) graphics.DrawRectangle(greenPen, getSquareRect(from));
            if (ChessGame.isOnBoard(to)) graphics.DrawRectangle(redPen, getSquareRect(to));
        }

        private Rectangle getSquareRect(ChessGame.Point p)
        {
            Rectangle squareRect = new Rectangle(p.x * boardSquareWidth + boardHOffset,
                (boardSize - 1 - p.y) * boardSquareHeight + boardVOffset, boardSquareWidth, boardSquareHeight);
            return squareRect;
        }

        private void recapitulateGame()
        {
            theChessGame.setupBoard();
            for (int i = 0; i < moveIndex; i++)
            {
                theChessGame.makeMove(moveHistory[i]);
            }
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            if(radioButtonResign.Checked)
            {
                txtMessage.Text = "I accept your resignation. Well played.";
                btnSubmit.Enabled = false;
                return;
            }
            string prependMsg = "";
            if (radioButtonUserDecides.Checked)
            {
                ChessGame.Point from, to;
                if (!getFromTo(out from, out to, true)) return;
                ChessGame.ChessMove theMove = new ChessGame.ChessMove(ref from, ref to);
                if (!theChessGame.makeMove(theMove))
                {
                    txtMessage.Text = "Sorry, that move is illegal. Please try again.";
                    return;
                }
                moveHistory.Add(theMove); moveIndex++; undoMoveToolStripMenuItem.Enabled = true;
                drawBoard();
                if (theChessGame.inCheckmate())
                {
                    txtMessage.Text = "I am checkmated! Nice game.";
                    btnSubmit.Enabled = false;
                    return;
                }
                if (theChessGame.inCheck())
                {
                    prependMsg = "I am in check!";
                }
            }
            ChessGameForm.ActiveForm.UseWaitCursor = true;
            ChessGameForm.ActiveForm.Update();
            txtMessage.Text = prependMsg + "Thinking...";
            int totalMoves = 0;
            ChessGame.ChessMove toMake = getMove(theChessGame, ref totalMoves);
            ChessGameForm.ActiveForm.UseWaitCursor = false;
            theChessGame.makeMove(toMake);
            txtMessage.Text = "After considering " + totalMoves + " moves, I have decided to move from " + toMake.origin.x + "," + toMake.origin.y + " to " + toMake.destination.x + "," + toMake.destination.y + ".";
            if(theChessGame.inCheckmate())
            {
                txtMessage.Text += " Checkmate! Nice game.";
                btnSubmit.Enabled = false;
            }
            else if(theChessGame.inCheck())
            {
                txtMessage.Text += " Check!";
            }
            moveHistory.Add(toMake); moveIndex++; undoMoveToolStripMenuItem.Enabled = true;
            drawBoard();
        }

        private ChessGame.ChessMove getMove(ChessGame aGame, ref int totalMoves)
        {
            int lookAhead = 1;
            ChessGame.ChessMove toMake = new ChessGame.ChessMove();
            const int MAX_TIME_IN_MILLISECONDS = 5000;
            int timeLimitInMilliseconds = MAX_TIME_IN_MILLISECONDS;
            DateTime startTime = DateTime.Now;
            while (timeLimitInMilliseconds >= 0)
            {
                int tempMoveTotal = 0;
                var tokenSource = new CancellationTokenSource();
                var token = tokenSource.Token;
                Task<ChessGame.ChessMove> findMoveThread = new Task<ChessGame.ChessMove>(() => aGame.bestMove(lookAhead, ref tempMoveTotal, token), token);
                findMoveThread.Start();
                findMoveThread.Wait(timeLimitInMilliseconds);
                if (!findMoveThread.IsCompleted)
                {
                    tokenSource.Cancel();
                    findMoveThread.Wait();
                    break;
                }
                toMake = findMoveThread.Result;
                totalMoves = tempMoveTotal;
                DateTime currentTime = DateTime.Now;
                TimeSpan elapsedTime = currentTime - startTime;
                timeLimitInMilliseconds = MAX_TIME_IN_MILLISECONDS - (int)elapsedTime.TotalMilliseconds;
                lookAhead++;
            }
            return toMake;
        }

        private bool getFromTo(out ChessGame.Point from, out ChessGame.Point to, bool report = false)
        {
            bool retValue = true;
            try
            {
                string[] fromStr = textBox2.Text.Split(',');
                from = new ChessGame.Point(Int32.Parse(fromStr[0]), Int32.Parse(fromStr[1]));
                string[] toStr = textBox1.Text.Split(',');
                to = new ChessGame.Point(Int32.Parse(toStr[0]), Int32.Parse(toStr[1]));
            }
            catch (Exception)
            {
                retValue = false;
                from = to = new ChessGame.Point();
                if (report) txtMessage.Text = "Sorry, that move is not in the correct format. Please try again.";
            }
            return retValue;
        }

        private void undoMoveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            moveIndex--;
            recapitulateGame();
            drawBoard();
            redoMoveToolStripMenuItem.Enabled = true;
            if(moveIndex == 0)
            {
                undoMoveToolStripMenuItem.Enabled = false;
            }
        }

        private void redoMoveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            moveIndex++;
            recapitulateGame();
            drawBoard();
            undoMoveToolStripMenuItem.Enabled = true;
            if(moveIndex == moveHistory.Count)
            {
                redoMoveToolStripMenuItem.Enabled = false;
            }
        }

        private void autoMatchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChessGame[] duelers = new ChessGame[2];
            duelers[0] = new ChessGame();
            duelers[1] = new ChessGame();
            theChessGame = new ChessGame();
            ChessGame.PLAYER whoseTurn = ChessGame.PLAYER.WHITE;
            int totalMoves = 0;
            txtMessage.Text = "Match AutoPlay:";
            drawBoard();
            int numTurns = 0;
            while (true)
            {
                int i = (int)whoseTurn;
                ChessGame.ChessMove toMake = getMove(duelers[i], ref totalMoves);
                duelers[i].makeMove(toMake);
                duelers[1 - i].makeMove(toMake);
                theChessGame.makeMove(toMake);
                numTurns++;
                txtMessage.Text += "\r\n" + numTurns + ". " + toMake;
                this.Refresh();
                drawBoard();
            }
        }

        private void ChessGame_Load(object sender, EventArgs e)
        {

        }

        private void panelChessboard_Paint()
        {

        }

        private void startNewGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            theChessGame = new ChessGame();
            moveHistory = new List<ChessGame.ChessMove>();
            moveIndex = 0;
            drawBoard();
            this.Click += form_Click;           
            undoMoveToolStripMenuItem.Enabled = redoMoveToolStripMenuItem.Enabled = false;
            btnSubmit.Enabled = true;
        }
    }
}
