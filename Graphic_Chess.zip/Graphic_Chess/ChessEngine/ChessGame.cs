﻿//Michael Brannon
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace GraphicChess
{
    public class ChessGame
    {
        public const int boardSize = 8;
        public struct Point
        {
            public int x;
            public int y;
            public Point(int xVal, int yVal) { x = xVal; y = yVal; }
            public static bool operator ==(Point p, Point q) { return p.x == q.x && p.y == q.y; }
            public static bool operator !=(Point p, Point q) { return !(p == q); }
            public override int GetHashCode()
            {
                return base.GetHashCode();
            }
            public override bool Equals(object obj)
            {
                return base.Equals(obj);
            }

            public override string ToString()
            {
                return "(" + x + "," + y + ")";
            }
        }

        public struct ChessMove
        {
            public Point origin;
            public Point destination;
            public ChessMove(ref Point theOrigin, ref Point theDestination) { origin = theOrigin; destination = theDestination; }
            public static bool operator ==(ChessMove m1, ChessMove m2) { return m1.origin == m2.origin && m1.destination == m2.destination; }
            public static bool operator !=(ChessMove m1, ChessMove m2) { return !(m1 == m2); }
            public override int GetHashCode()
            {
                return base.GetHashCode();
            }
            public override bool Equals(object obj)
            {
                return base.Equals(obj);
            }
            public override string ToString()
            {
                return "from " + origin + "to " + destination;
            }
        };

        public abstract class Piece
        {
            public PLAYER whosePiece;
            public Point boardLocation;
            public double value;
            public System.Drawing.Bitmap imageFile;
            public Piece(int xLocation, int yLocation, PLAYER owner, double theValue = 0)
            {
                boardLocation.x = xLocation;
                boardLocation.y = yLocation;
                whosePiece = owner;
                value = theValue;
                if (owner != PLAYER.WHITE) value *= -1;
            }
            public abstract int getLegalMoves(List<ChessMove> moves);
        }

        private class Pawn : Piece
        {
            public Pawn(int xLocation, int yLocation, PLAYER owner) : base(xLocation, yLocation, owner, 1)
            {
                imageFile = (owner == PLAYER.WHITE) ? ChessEngine.RiceImages.wpawn : ChessEngine.RiceImages.bpawn;
            }
            public override int getLegalMoves(List<ChessMove> moves)
            {
                int numMoves = 0;
                PLAYER opponent;
                int direction, baseRank, farEnd;
                ChessMove curMove;

                if (whosePiece == PLAYER.WHITE)
                {
                    opponent = PLAYER.BLACK;
                    direction = 1;
                    baseRank = 1;
                    farEnd = boardSize - 1;
                }
                else
                {
                    opponent = PLAYER.WHITE;
                    direction = -1;
                    baseRank = boardSize - 2;
                    farEnd = 0;
                }

                if (boardLocation.y != farEnd && board[boardLocation.x, boardLocation.y + direction] == null)
                {
                    curMove.origin = boardLocation;
                    curMove.destination.x = boardLocation.x;
                    curMove.destination.y = boardLocation.y + direction;
                    moves.Add(curMove);
                    numMoves++;
                }

                if (boardLocation.y == baseRank && board[boardLocation.x, boardLocation.y + direction] == null &&
                    board[boardLocation.x, boardLocation.y + 2 * direction] == null)
                {
                    curMove.origin = boardLocation;
                    curMove.destination.x = boardLocation.x;
                    curMove.destination.y = boardLocation.y + 2 * direction;
                    moves.Add(curMove);
                    numMoves++;
                }

                if (boardLocation.y != farEnd && boardLocation.x > 0 &&
                    board[boardLocation.x - 1, boardLocation.y + direction] != null &&
                    board[boardLocation.x - 1, boardLocation.y + direction].whosePiece == opponent)
                {
                    //Capture an enemy piece.
                    curMove.origin = boardLocation;
                    curMove.destination.x = boardLocation.x - 1;
                    curMove.destination.y = boardLocation.y + direction;
                    moves.Add(curMove);
                    numMoves++;
                }

                if (boardLocation.y != farEnd && boardLocation.x < boardSize - 1 &&
                    board[boardLocation.x + 1, boardLocation.y + direction] != null &&
                    board[boardLocation.x + 1, boardLocation.y + direction].whosePiece == opponent)
                {
                    //Capture an enemy piece.
                    curMove.origin = boardLocation;
                    curMove.destination.x = boardLocation.x + 1;
                    curMove.destination.y = boardLocation.y + direction;
                    moves.Add(curMove);
                    numMoves++;
                }

                return numMoves;
            }
        }

        private class Knight : Piece
        {
            public Knight(int xLocation, int yLocation, PLAYER owner) : base(xLocation, yLocation, owner, 3)
            {
                imageFile = (owner == PLAYER.WHITE) ? ChessEngine.RiceImages.wknight : ChessEngine.RiceImages.bknight;
            }
            public override int getLegalMoves(List<ChessMove> moves)
            {
                int numMoves = 0;
                int dx, dy;
                Point destination;
                ChessMove curMove;

                for (dx = -2; dx <= 2; dx++)
                {
                    for (dy = -2; dy <= 2; dy++)
                    {
                        //Knights can move 2 squares in one direction and 1 square in another.
                        if (Math.Abs(dx) + Math.Abs(dy) != 3) continue;

                        destination.x = boardLocation.x + dx;
                        destination.y = boardLocation.y + dy;
                        if (!isOnBoard(destination)) continue;
                        Piece p = board[destination.x, destination.y];

                        if (p == null || p.whosePiece != whosePiece)
                        {
                            curMove.origin = boardLocation;
                            curMove.destination = destination;
                            moves.Add(curMove);
                            numMoves++;
                        }
                    }
                }

                return numMoves;
            }
        }

        private class Bishop : Piece
        {
            public Bishop(int xLocation, int yLocation, PLAYER owner) : base(xLocation, yLocation, owner, 3.1)
            {
                imageFile = (owner == PLAYER.WHITE) ? ChessEngine.RiceImages.wbishop : ChessEngine.RiceImages.bbishop;
            }
            public override int getLegalMoves(List<ChessMove> moves)
            {
                int numMoves = 0;
                int i, xDirection, yDirection;
                Point destination;
                ChessMove curMove;

                for (xDirection = -1; xDirection <= 1; xDirection += 2)
                {
                    for (yDirection = -1; yDirection <= 1; yDirection += 2)
                    {
                        for (i = 1; i < boardSize; i++)
                        {
                            destination.x = boardLocation.x + i * xDirection;
                            destination.y = boardLocation.y + i * yDirection;
                            if (!isOnBoard(destination)) break;
                            Piece p = board[destination.x, destination.y];

                            if (p == null || p.whosePiece != whosePiece)
                            {
                                curMove.origin = boardLocation;
                                curMove.destination = destination;
                                moves.Add(curMove);
                                numMoves++;
                            }

                            //A bishop cannot move through other pieces.
                            if (p != null) break;
                        }
                    }
                }

                return numMoves;
            }
        }

        private class Rook : Piece
        {
            public Rook(int xLocation, int yLocation, PLAYER owner) : base(xLocation, yLocation, owner, 5)
            {
                imageFile = (owner == PLAYER.WHITE) ? ChessEngine.RiceImages.wrook : ChessEngine.RiceImages.brook;
            }
            public override int getLegalMoves(List<ChessMove> moves)
            {
                int numMoves = 0;//just for fun, to scare the human player!
                int i, xDirection, yDirection;
                Point destination;
                ChessMove curMove;

                for (xDirection = -1; xDirection <= 1; xDirection++)
                {
                    for (yDirection = -1; yDirection <= 1; yDirection++)
                    {
                        if (Math.Abs(xDirection) + Math.Abs(yDirection) > 1) continue;//rooks can't move diagonally!

                        for (i = 1; i < boardSize; i++)
                        {
                            destination.x = boardLocation.x + i * xDirection;
                            destination.y = boardLocation.y + i * yDirection;
                            if (!isOnBoard(destination)) break;
                            Piece p = board[destination.x, destination.y];

                            if (p == null || p.whosePiece != whosePiece)
                            {
                                curMove.origin = boardLocation;
                                curMove.destination = destination;
                                moves.Add(curMove);
                                numMoves++;
                            }

                            //A rook cannot move through other pieces.
                            if (p != null) break;
                        }
                    }
                }

                return numMoves;
            }
        }

        private class Queen : Piece
        {
            public Queen(int xLocation, int yLocation, PLAYER owner) : base(xLocation, yLocation, owner, 9)
            {
                imageFile = (owner == PLAYER.WHITE) ? ChessEngine.RiceImages.wqueen : ChessEngine.RiceImages.bqueen;
            }
            public override int getLegalMoves(List<ChessMove> moves)
            {
                int numMoves = 0;

                int i, xDirection, yDirection;
                Point destination;
                ChessMove curMove;

                // Rook-like movement
                for (xDirection = -1; xDirection <= 1; xDirection++)
                {
                    for (yDirection = -1; yDirection <= 1; yDirection++)
                    {
                        if (Math.Abs(xDirection) + Math.Abs(yDirection) > 1) continue; // Rook moves along rows or columns

                        for (i = 1; i < boardSize; i++)
                        {
                            destination.x = boardLocation.x + i * xDirection;
                            destination.y = boardLocation.y + i * yDirection;
                            if (!isOnBoard(destination)) break;
                            Piece p = board[destination.x, destination.y];

                            if (p == null || p.whosePiece != whosePiece)
                            {
                                curMove.origin = boardLocation;
                                curMove.destination = destination;
                                moves.Add(curMove);
                                numMoves++;
                            }

                            if (p != null) break;
                        }
                    }
                }

                // Bishop-like movement
                for (xDirection = -1; xDirection <= 1; xDirection += 2)
                {
                    for (yDirection = -1; yDirection <= 1; yDirection += 2)
                    {
                        for (i = 1; i < boardSize; i++)
                        {
                            destination.x = boardLocation.x + i * xDirection;
                            destination.y = boardLocation.y + i * yDirection;
                            if (!isOnBoard(destination)) break;
                            Piece p = board[destination.x, destination.y];

                            if (p == null || p.whosePiece != whosePiece)
                            {
                                curMove.origin = boardLocation;
                                curMove.destination = destination;
                                moves.Add(curMove);
                                numMoves++;
                            }

                            if (p != null) break;
                        }
                    }

                }

                return numMoves;
            }
        }

        private class King : Piece
        {
            public King(int xLocation, int yLocation, PLAYER owner) : base(xLocation, yLocation, owner, 1000)
            {
                imageFile = (owner == PLAYER.WHITE) ? ChessEngine.RiceImages.wking : ChessEngine.RiceImages.bking;
            }
            public override int getLegalMoves(List<ChessMove> moves)
            {
                int numMoves = 0;
                int xDirection, yDirection;
                Point destination;
                ChessMove curMove;

                for (xDirection = -1; xDirection <= 1; xDirection++)
                {
                    for (yDirection = -1; yDirection <= 1; yDirection++)
                    {
                        destination.x = boardLocation.x + xDirection;
                        destination.y = boardLocation.y + yDirection;
                        if (!isOnBoard(destination)) continue;
                        Piece p = board[destination.x, destination.y];

                        if (p == null || p.whosePiece != whosePiece)
                        {
                            curMove.origin = boardLocation;
                            curMove.destination = destination;
                            moves.Add(curMove);
                            numMoves++;
                        }
                    }
                }

                return numMoves;
            }
        }

        private static Piece[,] board;
        private bool[] rook1Moved;
        private bool[] rook2Moved;
        private bool[] kingMoved;

        public ChessGame()
        {
            setupBoard();
        }

        public enum PLAYER
        {
            INVALID = -1, WHITE, BLACK
        }

        private PLAYER whoseTurn;

        public void setupBoard()
        {
            board = new Piece[boardSize, boardSize];
            rook1Moved = new bool[2];
            rook2Moved = new bool[2];
            kingMoved = new bool[2];

            int i, j;
            PLAYER player;

            for (i = 0; i < boardSize; i++)
            {
                for (j = 0; j < boardSize; j++)
                {
                    board[i, j] = null;
                }
            }

            for (player = PLAYER.WHITE; player <= PLAYER.BLACK; player++)
            {
                int pawnRank = (player == PLAYER.WHITE) ? 1 : 6;
                int baseRank = (player == PLAYER.WHITE) ? 0 : 7;
                for (i = 0; i < boardSize; i++)
                {
                    board[i, pawnRank] = new Pawn(i, pawnRank, player);
                }

                for (i = 0; i < 2; i++)
                {
                    board[i * 7, baseRank] = new Rook(i * 7, baseRank, player);
                    board[1 + i * 5, baseRank] = new Knight(1 + i * 5, baseRank, player);
                    board[2 + i * 3, baseRank] = new Bishop(2 + i * 3, baseRank, player);
                }

                board[3, baseRank] = new Queen(3, baseRank, player);
                board[4, baseRank] = new King(4, baseRank, player);
            }

            for (i = 0; i < 2; i++)
            {
                rook1Moved[i] = false;
                rook2Moved[i] = false;
                kingMoved[i] = false;
            }

            whoseTurn = PLAYER.WHITE;
        }

        public Piece getPiece(Point p)
        {
            return board[p.x, p.y];
        }

        public bool makeMove(ChessMove move, bool checkLegality = true)
        {
            if (checkLegality && !isLegalMove(move)) return false;

            Piece piece = board[move.origin.x, move.origin.y];
            board[move.destination.x, move.destination.y] = piece;
            board[move.origin.x, move.origin.y] = null;
            piece.boardLocation = move.destination;

            whoseTurn = opponent(whoseTurn);
            return true;
        }

        public ChessMove bestMove(int depth, ref int totalMoves, CancellationToken token)
        {
            double[] BEST_VALUE = new double[] { double.MaxValue, double.MinValue };
            ChessMove niceMove = new ChessMove();
            niceMove.origin.x = -1;
            List<ChessMove> moves = new List<ChessMove>();
            totalMoves = 0;
            int numMoves = getLegalMoves(moves);
            if (numMoves == 0) return niceMove;
            if (token.IsCancellationRequested)
            {
                return moves[0];
            }

            int bestIndex = 0;
            double bestValue = (whoseTurn == PLAYER.WHITE) ? double.MinValue : double.MaxValue;

            for (int i = 0; i < moves.Count; i++)
            {
                ChessMove move = moves[i];
                Piece capturedPiece = board[move.destination.x, move.destination.y];
                makeMove(move, false);
                double value = evaluatePosition(depth - 1, ref totalMoves, token);

                undoMove(move, capturedPiece);

                if ((whoseTurn == PLAYER.WHITE && value > bestValue) || (whoseTurn == PLAYER.BLACK && value < bestValue))
                {
                    bestValue = value;
                    bestIndex = i;
                }
            }
            return moves[bestIndex];
        }

        public static bool isOnBoard(Point p)
        {
            if (p.x >= 0 && p.y >= 0 && p.x < boardSize && p.y < boardSize) return true;
            return false;
        }

        public bool inCheck()
        {
            return false;
        }

        public bool inCheckmate()
        {
            return false;
        }

        private PLAYER opponent(PLAYER player)
        {
            if (player == PLAYER.WHITE) return PLAYER.BLACK;
            return PLAYER.WHITE;
        }

        private int getLegalMoves(List<ChessMove> moves)
        {
            int numMoves = 0;

            foreach (Piece p in board)
            {
                if (p == null || p.whosePiece != whoseTurn) continue;
                numMoves += p.getLegalMoves(moves);
            }

            return numMoves;
        }

        private double evaluatePosition(int depth, ref int totalMoves, CancellationToken token)
        {
            if (token.IsCancellationRequested)
            {
                return 0;
            }
            if (depth == 0)
            {
                return objectiveFunction();
            }
            List<ChessMove> moves = new List<ChessMove>();
            int numMoves = getLegalMoves(moves);
            totalMoves += numMoves;
            if (numMoves == 0) return 0;

            double bestValue = (whoseTurn == PLAYER.WHITE) ? double.MinValue : double.MaxValue;

            foreach (ChessMove move in moves)
            {
                Piece capturedPiece = board[move.destination.x, move.destination.y];
                makeMove(move, false);

                double value = evaluatePosition(depth - 1, ref totalMoves, token);

                undoMove(move, capturedPiece);

                if (whoseTurn == PLAYER.WHITE)
                {
                    bestValue = Math.Max(bestValue, value);
                }
                else
                {
                    bestValue = Math.Min(bestValue, value);
                }
            }

            return bestValue;
        }

        private double objectiveFunction()
        {
            double totalValue = 0;
            foreach (Piece piece in board)
            {
                if (piece != null)
                {
                    totalValue += piece.value;
                }
            }
            return totalValue;
        }

        private bool isLegalMove(ChessMove move)
        {
            if (!isOnBoard(move.origin)) return false;
            if (!isOnBoard(move.destination)) return false;

            List<ChessMove> moves = new List<ChessMove>();
            int numMoves = getLegalMoves(moves);

            return moves.Contains(move);
        }

        private void undoMove(ChessMove m, Piece formerOccupant)
        {
            Piece mover = board[m.destination.x, m.destination.y];
            mover.boardLocation = m.origin;
            board[m.origin.x, m.origin.y] = mover;
            board[m.destination.x, m.destination.y] = formerOccupant;
            whoseTurn = opponent(whoseTurn);
        }
    }
}
