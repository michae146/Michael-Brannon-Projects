#include "Stack.cpp"
#include <iostream>

// A helper function to print the top of the stack
template <class T>
void printTop(const Stack<T>& stack) {
    if (!stack.empty()) {
        std::cout << "Top of stack: " << stack.top() << std::endl;
    }
    else {
        std::cout << "Stack is empty" << std::endl;
    }
}

int main() {
    // Test 1: Basic stack functionality (push, top, pop, empty)
    std::cout << "Test 1: Basic stack functionality\n";
    Stack<int> stack(5);  // A stack with a capacity of 5

    stack.push(10);
    stack.push(20);
    stack.push(30);

    printTop(stack);  // Should print 30
    stack.pop();
    printTop(stack);  // Should print 20

    stack.push(40);
    printTop(stack);  // Should print 40

    // Test 2: Copy constructor
    std::cout << "\nTest 2: Copy constructor\n";
    Stack<int> copyStack(stack);
    printTop(copyStack);  // Should print the top of the copied stack (40)

    // Test 3: Move constructor
    std::cout << "\nTest 3: Move constructor\n";
    Stack<int> movedStack(std::move(stack));
    printTop(movedStack);  // Should print 40
    printTop(stack);       // Should print "Stack is empty" (because it was moved)

    // Test 4: Assignment operator
    std::cout << "\nTest 4: Assignment operator\n";
    Stack<int> anotherStack(5);
    anotherStack.push(100);
    anotherStack.push(200);
    anotherStack = movedStack;
    printTop(anotherStack);  // Should print 40 (the top of the moved stack)

    // Test 5: += operator for adding an item
    std::cout << "\nTest 5: += operator (adding item)\n";
    anotherStack += 50;
    printTop(anotherStack);  // Should print 50

    // Test 6: += operator for merging two stacks
    std::cout << "\nTest 6: += operator (merging stacks)\n";
    Stack<int> extraStack(5);
    extraStack.push(5);
    extraStack.push(15);
    anotherStack += extraStack;  // Should add the elements from extraStack
    printTop(anotherStack);  // Should print 15

    // Test 7: Operator-- for popping an element
    std::cout << "\nTest 7: Operator-- (popping element)\n";
    int poppedValue = --anotherStack;
    std::cout << "Popped value: " << poppedValue << std::endl;
    printTop(anotherStack);  // Should print the next top value after popping

    return 0;
}