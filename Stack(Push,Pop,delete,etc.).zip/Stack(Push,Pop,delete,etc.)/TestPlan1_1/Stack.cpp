//Michael Brannon

#include "Stack.h"
#include <stdexcept>

template <class T>
Stack<T>::Stack(int capacity)
{
	maxCapacity = capacity; 
	items = new T[maxCapacity];
	topItem = nullptr;
}
template <class T>
Stack<T>::Stack(Stack<T>&& toMove) noexcept
{
	maxCapacity = toMove.maxCapacity;
	items = toMove.items;
	topItem = toMove.topItem;

	toMove.items = nullptr;
	toMove.topItem = nullptr;
	toMove.maxCapacity = 0;
}

template <class T>
Stack<T>::Stack(const Stack<T>& original)
{
	maxCapacity = original.maxCapacity;
	items = new T[maxCapacity];
	topItem = nullptr;

	for (int i = 0; i < maxCapacity; i++)
	{
		items[i] = original.items[i];
	}
	if (original.topItem != nullptr)
	{
		topItem = items + (original.topItem - original.items);
	}
	else {
		topItem = nullptr;
	}
}

template <class T>
Stack<T>::~Stack()
{
	delete[] items;
	items = topItem = nullptr;
	maxCapacity = 0;
}
template <class T>
void Stack<T>::push(T item)
{
	if (topItem == items + maxCapacity - 1) 
	{
		throw std::overflow_error("Stack has overflown, so cannot push more items.");
	}
	if (topItem == nullptr) {
		topItem = items;
	}
	else {
		topItem++;
	}
	*topItem = item;
}

template <class T>
T Stack<T>::top() const
{
	if (empty()) 
	{
		throw std::underflow_error("Stack is empty, so there isn't a top item.");
	}
	return *topItem;
}
template <class T>
void Stack<T>::pop()
{
	if (empty()) 
	{
		throw std::underflow_error("No items to pop.");
	}
	if (topItem == items) {
		topItem = nullptr;
	}
	else {
		topItem--;
	}
}

template <class T>
bool Stack<T>::empty() const
{
	return topItem == nullptr;
}

template <class T>
T Stack<T>::operator--()
{
	if (empty()) 
	{
		throw std::underflow_error("Stack is empty so it can't decrement.");
	}
	T poppedValue = *topItem;
	pop();
	return poppedValue;
	
}

template <class T>
Stack<T>& Stack<T>::operator+=(const Stack<T>& RHS)
{
	for (T* itemPointer = RHS.items; itemPointer <= RHS.topItem; itemPointer++)
	{
		push(*itemPointer);
	}
	return *this;
}

template <class T>
Stack<T>& Stack<T>::operator+=(T item)
{
	push(item);
	return *this;
}

template <class T>
Stack<T>& Stack<T>::operator=(const Stack<T>& RHS)
{
	if (this != &RHS) {
		delete[] items;  

		maxCapacity = RHS.maxCapacity;
		items = new T[maxCapacity];  
		
		for (int i = 0; i < maxCapacity; i++) {
			items[i] = RHS.items[i];
		}

		if (RHS.topItem != nullptr) {
			topItem = items + (RHS.topItem - RHS.items);
		}
		else {
			topItem = nullptr;
		}
	}
	return *this;
}

template <class T>
Stack<T>& Stack<T>::operator=(Stack<T>&& toMove) 
{
	
		delete[] items;  
		 
		items = toMove.items;
		topItem = toMove.topItem;
		maxCapacity = toMove.maxCapacity;
		
		toMove.items = nullptr;
		toMove.topItem = nullptr;
		toMove.maxCapacity = 0;
	
	return *this;
}