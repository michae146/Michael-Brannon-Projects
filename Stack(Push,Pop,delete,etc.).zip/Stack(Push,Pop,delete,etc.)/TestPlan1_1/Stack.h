//Michael Brannon

#pragma once
template < class T >
class Stack
{
private:
    T* items;           // Pointer to the array of stack items
    T* topItem;         // Pointer to the top item in the stack
    int maxCapacity;    // Maximum number of items the stack can hold
public:
    Stack(int capacity);                // Constructor: initializes stack with max capacity
    Stack(const Stack<T>& original);    // Copy constructor: deep copy from another stack
    Stack(Stack<T>&& toMove) noexcept;  // Move constructor: transfers resources, no copy
    ~Stack();                           // Destructor: cleans up dynamically allocated memory
    void push(T item);                  // Adds an item to the top of the stack
    T top() const;                      // Returns the top item of the stack without removing it
    void pop();                         // Removes the top item from the stack
    bool empty() const;                 // Checks if the stack is empty
    T operator--();                     // Overloads '--' to possibly remove or access top item
    Stack<T>& operator+=(const Stack<T>& RHS);  // Combines another stack with this one
    Stack<T>& operator+=(T item);       // Adds a single item to the stack
    Stack<T>& operator=(const Stack<T>& RHS);   // Copy assignment: deep copy another stack
    Stack<T>& operator=(Stack<T>&& toMove);     // Move assignment: shallow copy another stack
};