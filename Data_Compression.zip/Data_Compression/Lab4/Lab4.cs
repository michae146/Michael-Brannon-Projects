﻿//Michael Brannon

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using static Lab4.Compressor;
using System.Collections;

namespace Lab4
{
    public class RootedBinaryTree<T> : IComparable<RootedBinaryTree<T>>
        where T : IComparable<T>
    {
        private class Node
        {
            public T nodeData;
            public Node leftChild;
            public Node rightChild;
            public Node parent;
        };
        private Node root;
        private Node currentPosition;

        public int CompareTo(RootedBinaryTree<T> otherTree)
        {
            return root.nodeData.CompareTo(otherTree.root.nodeData);
        }

        public RootedBinaryTree(T rootData)
        {
            root = new Node();
            root.nodeData = rootData;
            root.leftChild = null;
            root.rightChild = null;
            root.parent = null;
            currentPosition = root;
        }

        public void toRoot()
        {
            currentPosition = root;
        }

        public bool moveLeft()
        {
            if (currentPosition.leftChild == null)
            {
                return false;
            }
            currentPosition = currentPosition.leftChild;
            return true;
        }

        public bool moveRight()
        {
            if (currentPosition.rightChild == null)
            {
                return false;
            }
            currentPosition = currentPosition.rightChild;
            return true;
        }

        public bool moveUp()
        {
            if (currentPosition.parent == null)
            {
                return false;
            }
            currentPosition = currentPosition.parent;
            return true;

        }

        public T getData()
        {
            if (currentPosition == null)
            {
                throw new InvalidOperationException("The current position is null.");
            }
            return currentPosition.nodeData;
        }

        public void combineTrees(RootedBinaryTree<T> leftTree, RootedBinaryTree<T> rightTree)
        {
            if (leftTree == null || rightTree == null)
            {
                throw new ArgumentNullException("Trees cannot be null");
            }
            root.leftChild = leftTree.root;
            root.rightChild = rightTree.root;
            leftTree.root.parent = root;
            rightTree.root.parent = root;
        }

        public void setNodeData(T nodeData)
        {
            currentPosition.nodeData = nodeData;
        }
    }

    public class Compressor
    {
        static byte bitsPerByte = 8;

        public class Word : IComparable<Word>
        {
            public string plainWord;
            public double probability;
            public string codeWord;

            public Word(string thePlainWord, double theProbability, string theCodeWord)
            {
                plainWord = thePlainWord;
                probability = theProbability;
                codeWord = theCodeWord;
            }

            public int CompareTo(Word otherWord)
            {
                int ret = probability.CompareTo(otherWord.probability);
                if (ret == 0)
                {
                    ret = ((int)plainWord[0] < (int)otherWord.plainWord[0]) ? -1 : 1;//plainWord.CompareTo(otherWord.plainWord);//
                }

                return ret;
            }
        }

        public static void compress(string inputFileName, string outputFileName, bool writeDictionary = false)
        {
            Dictionary<string, Word> theWords = new Dictionary<string, Word>();
            getWordsAndProbs(inputFileName, theWords);
            huffman(theWords); // Assign Huffman codes
            writeOutputFile(inputFileName, outputFileName, theWords);

            if (writeDictionary)
            {
                Console.WriteLine("Words and their frequencies:");
                foreach (var entry in theWords)
                {
                    Console.WriteLine($"{entry.Key}: {entry.Value.probability}, Huffman Code: {entry.Value.codeWord}");
                }
            }

        }
        private static void writeOutputFile(string inputFileName, string outputFileName, Dictionary<string, Word> theWords)
        {
            string binaryOutputString = "";
            FileStream inputFile = File.OpenRead(inputFileName);
            FileStream outputFile = File.OpenWrite(outputFileName);

            while (true)
            {
                int readByte = inputFile.ReadByte();
                if (readByte < 0) break;
                String plainWord = ((char)readByte).ToString();
                binaryOutputString += theWords[plainWord].codeWord;
                writeOutputByBytes(ref binaryOutputString, outputFile);

            }

            if(binaryOutputString.Length > 0)
            {
                int paddingLength = bitsPerByte - binaryOutputString.Length % bitsPerByte;
                binaryOutputString = binaryOutputString.PadRight(binaryOutputString.Length + paddingLength, '0');
                writeOutputByBytes(ref binaryOutputString, outputFile);
            }

            inputFile.Close();
            outputFile.Close();
        }

        private static void writeOutputByBytes(ref string binaryOutputString, FileStream outputFile)
        {
            while (binaryOutputString.Length >= bitsPerByte)
            {
                string byteToWriteString = binaryOutputString.Substring(0, bitsPerByte);
                byte byteToWrite = Convert.ToByte(byteToWriteString, 2);
                outputFile.WriteByte(byteToWrite);
                binaryOutputString = binaryOutputString.Substring(bitsPerByte);
            }
        }

        public static void getWordsAndProbs(string inputFileName, Dictionary<string, Word> theWords)//input conditions: theWords is empty and not null; output conditions: theWords contains correct plainWord and probability fields, but codeWords are empty strings.
        {
            FileStream inputFile = File.OpenRead(inputFileName);

            long TotalNumberOfMessages = 0;
            while (true)
            {
                int readByte = inputFile.ReadByte();
                if (readByte < 0) break; 
                TotalNumberOfMessages++;
                string plainWord = ((char)readByte).ToString();
                if (!theWords.Keys.Contains(plainWord))
                {
                    Word theWord = new Word(plainWord, 0, "");
                    theWords.Add(plainWord, theWord);

                }
                Word currentWord = theWords[plainWord];
                currentWord.probability++;
            }
            inputFile.Close();
            foreach (Word word in theWords.Values)
            {
                word.probability /= TotalNumberOfMessages;
            }

        }


        public static void huffman(Dictionary<string, Word> theWords)//input conditions: theWords contains plainWord and probability fields, but empty codeWord strings; output conditions: codeWord fields are correct too
        {
            List<Word> wordList = theWords.Values.ToList();
            wordList.Sort();  

            List<RootedBinaryTree<Word>> trees = new List<RootedBinaryTree<Word>>();

            foreach (var word in wordList)
            {
                var tree = new RootedBinaryTree<Word>(word);
                trees.Add(tree);
            }

            while (trees.Count > 1)
            {
                trees.Sort((t1, t2) => t1.getData().probability.CompareTo(t2.getData().probability));

                var leftTree = trees[0];
                var rightTree = trees[1];

                var combinedTree = new RootedBinaryTree<Word>(new Word("", leftTree.getData().probability + rightTree.getData().probability, ""));
                combinedTree.combineTrees(leftTree, rightTree);

                trees.RemoveAt(0);
                trees.RemoveAt(0);
                trees.Add(combinedTree);
            }

            
            assignHuffmanCodes(trees[0]);
        }

        private static void assignHuffmanCodes(RootedBinaryTree<Word> tree, string code = "")
        {
            if (tree == null) return;

            if (tree.getData().plainWord != null && !string.IsNullOrEmpty(tree.getData().plainWord))
            {
                tree.getData().codeWord = code;
                return;
            }

            if (tree.moveLeft())
            {
                assignHuffmanCodes(tree, code + "0");
                tree.moveUp();  
            }

            if (tree.moveRight())
            {
                assignHuffmanCodes(tree, code + "1");
                tree.moveUp();  
            }
        }


        public static void decompress(string inputFileName, string outputFileName)
        {
            /*
            Dictionary<string, Word> theWords = new Dictionary<string, Word>();

            FileStream inputFile = File.OpenRead(inputFileName);
            StreamWriter outputFile = new StreamWriter(outputFileName);

            StringBuilder binaryInputString = new StringBuilder();

            while (true)
            {
                int readByte = inputFile.ReadByte();
                if (readByte < 0) break;
                binaryInputString.Append(Convert.ToString(readByte, 2).PadLeft(8, '0'));
            }
            inputFile.Close(); */              
        }
    }
}
