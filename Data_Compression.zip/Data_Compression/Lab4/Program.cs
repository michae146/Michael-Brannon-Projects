﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Starting compression...");

            string inputFileName = "TestPlan4.txt";
            string outputFileName = "TestPlan4_compressed.bin";

            

            // Compress the file
            Lab4.Compressor.compress(inputFileName, outputFileName, writeDictionary: true);

            Console.WriteLine("Compression complete.");

            // Print out the binary data from the compressed file
            if (File.Exists(outputFileName))
            {
                byte[] compressedData = File.ReadAllBytes(outputFileName);
                StringBuilder binaryString = new StringBuilder();

                foreach (byte b in compressedData)
                {
                    binaryString.Append(Convert.ToString(b, 2).PadLeft(8, '0')); // Convert each byte to binary string
                }

                Console.WriteLine("Compressed Binary Data:");
                Console.WriteLine(binaryString.ToString());
            }
            else
            {
                Console.WriteLine("Compressed file not found.");
            }

            // Optionally, decompress the file
            string decompressedFileName = "TestPlan4_decompressed.txt";
            Lab4.Compressor.decompress(outputFileName, decompressedFileName);

            Console.WriteLine("Decompression complete.");

            // Read and print the decompressed content
            if (File.Exists(decompressedFileName))
            {
                string decompressedContent = File.ReadAllText(decompressedFileName);
                Console.WriteLine("Decompressed Content:");
                Console.WriteLine(decompressedContent);
            }
            else
            {
                Console.WriteLine("Decompressed file not found.");
            }
        }
    }
}
