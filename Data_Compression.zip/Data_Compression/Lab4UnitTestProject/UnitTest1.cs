﻿//Michael Brannon

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.IO;

namespace Lab4UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Test_getWordsAndProbs()
        {
            string inputFileName = "..\\..\\..\\TestPlan4.txt"; ;
            var theWords = new Dictionary<string, Lab4.Compressor.Word>();
            Lab4.Compressor.getWordsAndProbs(inputFileName, theWords);
            var expectedWords = new Dictionary<string, Lab4.Compressor.Word>();
            

            Lab4.Compressor.Word A = new Lab4.Compressor.Word(thePlainWord: "A", theProbability: 0.13, theCodeWord: "");
            expectedWords.Add(A.plainWord, A);
            Lab4.Compressor.Word B = new Lab4.Compressor.Word(thePlainWord: "B", theProbability: 0.19, theCodeWord: "");
            expectedWords.Add(B.plainWord, B);
            Lab4.Compressor.Word C = new Lab4.Compressor.Word(thePlainWord: "C", theProbability: 0.16, theCodeWord: "");
            expectedWords.Add(C.plainWord, C);
            Lab4.Compressor.Word D = new Lab4.Compressor.Word(thePlainWord: "D", theProbability: 0.1, theCodeWord: "");
            expectedWords.Add(D.plainWord, D);
            Lab4.Compressor.Word E = new Lab4.Compressor.Word(thePlainWord: "E", theProbability: 0.09, theCodeWord: "");
            expectedWords.Add(E.plainWord, E);
            Lab4.Compressor.Word F = new Lab4.Compressor.Word(thePlainWord: "F", theProbability: 0.07, theCodeWord: "");
            expectedWords.Add(F.plainWord, F);
            Lab4.Compressor.Word G = new Lab4.Compressor.Word(thePlainWord: "G", theProbability: 0.12, theCodeWord: "");
            expectedWords.Add(G.plainWord, G);
            Lab4.Compressor.Word H = new Lab4.Compressor.Word(thePlainWord: "H", theProbability: 0.12, theCodeWord: "");
            expectedWords.Add(H.plainWord, H);

            double errorTolerance = 0.00001;
            foreach (string plainWord in expectedWords.Keys)
            {
                Assert.AreEqual(expectedWords[plainWord].probability, theWords[plainWord].probability, errorTolerance);

            }
        }

        [TestMethod]
        public void Test_huffman()
        {
            string inputFileName = "..\\..\\..\\TestPlan4.txt"; ;
            var theWords = new Dictionary<string, Lab4.Compressor.Word>();
            Lab4.Compressor.getWordsAndProbs(inputFileName, theWords);
            Lab4.Compressor.huffman(theWords);
            var expectedWords = new Dictionary<string, Lab4.Compressor.Word>();

            Lab4.Compressor.Word A = new Lab4.Compressor.Word(thePlainWord: "A", theProbability: 0.13, theCodeWord: "100");
            expectedWords.Add(A.plainWord, A);
            Lab4.Compressor.Word B = new Lab4.Compressor.Word(thePlainWord: "B", theProbability: 0.19, theCodeWord: "00");
            expectedWords.Add(B.plainWord, B);
            Lab4.Compressor.Word C = new Lab4.Compressor.Word(thePlainWord: "C", theProbability: 0.16, theCodeWord: "110");
            expectedWords.Add(C.plainWord, C);
            Lab4.Compressor.Word D = new Lab4.Compressor.Word(thePlainWord: "D", theProbability: 0.1, theCodeWord: "010");
            expectedWords.Add(D.plainWord, D);
            Lab4.Compressor.Word E = new Lab4.Compressor.Word(thePlainWord: "E", theProbability: 0.14, theCodeWord: "101");
            expectedWords.Add(E.plainWord, E);
            Lab4.Compressor.Word F = new Lab4.Compressor.Word(thePlainWord: "F", theProbability: 0.09, theCodeWord: "1111");
            expectedWords.Add(F.plainWord, F);
            Lab4.Compressor.Word G = new Lab4.Compressor.Word(thePlainWord: "G", theProbability: 0.07, theCodeWord: "1110");
            expectedWords.Add(G.plainWord, G);
            Lab4.Compressor.Word H = new Lab4.Compressor.Word(thePlainWord: "H", theProbability: 0.12, theCodeWord: "011");
            expectedWords.Add(H.plainWord, H);
            foreach (string plainWord in expectedWords.Keys)
            {
                Assert.AreEqual(expectedWords[plainWord].codeWord, theWords[plainWord].codeWord);
            }
        }

        [TestMethod]
        public void Test_output()
        {
            string inputFileName = "..\\..\\..\\TestPlan4.txt"; ;
            string outputFileName = "TestPlan4_compressed.bin";
            Lab4.Compressor.compress(inputFileName, outputFileName);
            FileStream inputFile = File.OpenRead(outputFileName);
            int[] expectedBytes = {01011010,11110101,11011101, 01110101 };//Expected first 4 bytes of the compressed output file.

            int numBytesRead = 0;
            for (int byteNum = 0; byteNum < 4; byteNum++)
            {
                int readByte = inputFile.ReadByte();
                if (readByte < 0) break;
                numBytesRead++;
                Assert.AreEqual(expectedBytes[byteNum], readByte);
            }
            Assert.AreEqual(4, numBytesRead);
            inputFile.Close();
        }
    }
}
